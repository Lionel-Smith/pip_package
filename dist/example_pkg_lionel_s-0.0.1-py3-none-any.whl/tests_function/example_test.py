def plus_6(number):
    return number+6